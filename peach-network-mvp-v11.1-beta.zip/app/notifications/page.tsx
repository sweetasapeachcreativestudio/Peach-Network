import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { AppHeader, BottomNav } from "../components/app-nav";

export default async function NotificationsPage(){
  const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)redirect("/auth?mode=signin");
  const admin=createAdminClient();const {data:profile}=await admin.from("profiles").select("full_name,role").eq("id",user.id).single();if(!profile)redirect("/auth?mode=signin");
  const role=profile.role==="creative"?"creative":"business";
  const alerts:{title:string;body:string;href:string}[]=[];
  let coins:number|undefined=undefined;

  if(role==="business"){
    const {data:business}=await admin.from("businesses").select("id").eq("owner_user_id",user.id).maybeSingle();
    if(business){
      const {data:wallet}=await admin.from("coin_wallets").select("available_coins").eq("business_id",business.id).maybeSingle();coins=wallet?.available_coins??0;
      const {data:projects}=await admin.from("projects").select("id,title,status,due_at").eq("business_id",business.id).order("created_at",{ascending:false}).limit(20);
      for(const p of projects??[]){
        if(p.status==="proof_uploaded"||p.status==="submitted")alerts.push({title:"A project needs your eyes.",body:`${p.title} has a proof or final delivery ready.`,href:`/projects/${p.id}`});
        if(p.status==="waiting_on_client")alerts.push({title:"Your creative is waiting on you.",body:`${p.title} needs client information before work can continue.`,href:`/projects/${p.id}`});
        if(p.due_at){const d=Math.ceil((new Date(p.due_at).getTime()-Date.now())/86400000);if(d>=0&&d<=3&&!['completed','cancelled'].includes(p.status))alerts.push({title:"Deadline coming up.",body:`${p.title} is due ${d===0?'today':`in ${d} day${d===1?'':'s'}`}.`,href:`/projects/${p.id}`})}
      }
    }
  } else {
    const {data:creative}=await admin.from("creatives").select("id").eq("user_id",user.id).maybeSingle();
    if(creative){
      const {data:offers}=await admin.from("project_offers").select("id,expires_at,projects(title)").eq("creative_id",creative.id).eq("status","sent").order("created_at",{ascending:false});
      for(const o of offers??[])alerts.push({title:"New Peach Match.",body:`${(o.projects as any)?.title??'A project'} is waiting for your response.`,href:"/creative/offers"});
      const {data:projects}=await admin.from("projects").select("id,title,status,due_at").eq("assigned_creative_id",creative.id).order("created_at",{ascending:false}).limit(20);
      for(const p of projects??[]){if(p.due_at){const d=Math.ceil((new Date(p.due_at).getTime()-Date.now())/86400000);if(d>=0&&d<=3&&!['completed','cancelled'].includes(p.status))alerts.push({title:"Project deadline coming up.",body:`${p.title} is due ${d===0?'today':`in ${d} day${d===1?'':'s'}`}.`,href:`/projects/${p.id}`})}}
    }
  }

  return <main className="app-shell"><AppHeader name={profile.full_name} role={role} coinCount={coins}/><div className="section-row"><div><span className="eyebrow">PEACH ALERTS</span><h2>What needs your attention.</h2><p>Important project, match and deadline activity in plain language.</p></div></div><section className="project-list">{alerts.slice(0,20).map((a,i)=><Link href={a.href} className="project-card" key={`${a.title}-${i}`}><h3>{a.title}</h3><p className="muted" style={{marginBottom:0}}>{a.body}</p></Link>)}{alerts.length===0&&<div className="empty-state"><div className="empty-mark"><i/><i/><i/></div><h2>You’re all caught up.</h2><p className="muted">Nothing needs your attention right now.</p></div>}</section><BottomNav role={role} active="home"/></main>
}
